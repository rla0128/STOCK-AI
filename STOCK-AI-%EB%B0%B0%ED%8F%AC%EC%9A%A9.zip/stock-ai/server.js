require("dotenv").config();
const express = require("express");
const path = require("path");
const AdmZip = require("adm-zip");
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json({ limit: "15mb" }));
app.use(express.static(path.join(__dirname, "public")));

async function getJson(url, options = {}) {
  const r = await fetch(url, { ...options, headers: { "User-Agent": "STOCK-AI/2.0 contact=admin@example.com", ...(options.headers || {}) } });
  if (!r.ok) throw new Error(`데이터 제공자 응답 오류 (${r.status})`);
  return r.json();
}
function resolveTicker({ market = "us", symbol = "", board = "kospi" }) {
  symbol = String(symbol).trim().toUpperCase().replace(/[^A-Z0-9.^=-]/g, "");
  if (!symbol) throw new Error("종목 코드를 입력하세요.");
  if (market === "kr") {
    if (!/^\d{6}$/.test(symbol)) throw new Error("국내 주식은 6자리 종목코드를 입력하세요. 예: 005930");
    return symbol + (board === "kosdaq" ? ".KQ" : ".KS");
  }
  if (market === "us" && /^[A-Z0-9.^=-]{1,15}$/.test(symbol)) return symbol;
  throw new Error("시장 또는 종목 코드를 확인하세요.");
}
app.get("/api/market", async (req, res) => {
  try {
    const market = req.query.market || "us", board = req.query.board || "kospi";
    const ticker = resolveTicker({ market, board, symbol: req.query.symbol || "AAPL" });
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=5d&interval=5m&includePrePost=false`;
    const raw = await getJson(url);
    const result = raw.chart?.result?.[0];
    if (!result) return res.status(404).json({ error: raw.chart?.error?.description || "해당 종목 데이터를 찾을 수 없습니다." });
    const q = result.indicators?.quote?.[0] || {}, timestamps = result.timestamp || [];
    const candles = timestamps.map((t, i) => ({ time: t, open: q.open?.[i], high: q.high?.[i], low: q.low?.[i], close: q.close?.[i], volume: q.volume?.[i] }))
      .filter(c => [c.open, c.high, c.low, c.close].every(Number.isFinite) && Number.isFinite(c.volume));
    if (!candles.length) return res.status(404).json({ error: "표시할 차트 데이터가 없습니다. 종목 코드와 거래소를 확인하세요." });
    const meta = result.meta || {}, price = Number(meta.regularMarketPrice ?? candles.at(-1).close);
    const prev = Number(meta.chartPreviousClose ?? meta.previousClose ?? candles[0].open);
    const high = Number(meta.regularMarketDayHigh ?? Math.max(...candles.map(c => c.high)));
    const low = Number(meta.regularMarketDayLow ?? Math.min(...candles.map(c => c.low)));
    res.json({ market, board, ticker, name: meta.longName || meta.shortName || ticker, currency: meta.currency || (market === "kr" ? "KRW" : "USD"), price,
      change24: prev ? ((price - prev) / prev) * 100 : 0, high24: high, low24: low,
      volume24: meta.regularMarketVolume ?? candles.at(-1).volume, marketState: meta.marketState || "UNKNOWN",
      exchangeName: meta.fullExchangeName || meta.exchangeName || "", candles });
  } catch (e) { res.status(502).json({ error: e.message || "주가 데이터를 불러오지 못했습니다." }); }
});

let dartCorpMap = null;
async function getDartCorpMap() {
  if (dartCorpMap) return dartCorpMap;
  if (!process.env.DART_API_KEY) throw new Error("국내 공시는 DART_API_KEY 설정 후 이용할 수 있습니다.");
  const response = await fetch(`https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key=${process.env.DART_API_KEY}`);
  if (!response.ok) throw new Error("DART 기업 코드 목록을 가져오지 못했습니다.");
  const zip = new AdmZip(Buffer.from(await response.arrayBuffer()));
  const xml = zip.getEntries().find(x => x.entryName.endsWith(".xml"))?.getData().toString("utf8");
  if (!xml) throw new Error("DART 기업 코드 파일을 읽지 못했습니다.");
  const map = new Map();
  for (const block of xml.matchAll(/<list>([\s\S]*?)<\/list>/g)) {
    const part = block[1];
    const code = part.match(/<corp_code>(.*?)<\/corp_code>/)?.[1];
    const stock = part.match(/<stock_code>(.*?)<\/stock_code>/)?.[1];
    if (code && stock?.trim()) map.set(stock.trim(), code.trim());
  }
  dartCorpMap = map;
  return map;
}
app.get("/api/filings", async (req, res) => {
  try {
    const market = req.query.market || "us", symbol = String(req.query.symbol || "").trim().toUpperCase();
    if (!symbol) throw new Error("종목 코드를 입력하세요.");
    const since = new Date(Date.now() - 1000 * 60 * 60 * 24 * 120).toISOString().slice(0, 10).replaceAll("-", "");
    if (market === "kr") {
      if (!/^\d{6}$/.test(symbol)) throw new Error("국내 종목코드는 6자리여야 합니다.");
      const map = await getDartCorpMap(), corp = map.get(symbol);
      if (!corp) return res.json({ source: "금융감독원 DART", configured: true, items: [], message: "DART에 등록된 공시 기업 코드를 찾지 못했습니다." });
      const url = new URL("https://opendart.fss.or.kr/api/list.json");
      url.searchParams.set("crtfc_key", process.env.DART_API_KEY); url.searchParams.set("corp_code", corp);
      url.searchParams.set("bgn_de", since); url.searchParams.set("end_de", new Date().toISOString().slice(0, 10).replaceAll("-", ""));
      url.searchParams.set("page_no", "1"); url.searchParams.set("page_count", "20");
      const data = await getJson(url);
      if (data.status !== "000" && data.status !== "013") throw new Error(data.message || "DART 공시 조회 실패");
      const items = (data.list || []).map(x => ({ title: x.report_nm, date: x.rcept_dt, company: x.corp_name, type: x.pblntf_ty, url: `https://dart.fss.or.kr/dsaf001/main.do?rcpNo=${x.rcept_no}`, source: "DART" }));
      return res.json({ source: "금융감독원 DART", configured: true, items });
    }
    if (market === "us") {
      const directory = await getJson("https://www.sec.gov/files/company_tickers.json", { headers: { "User-Agent": process.env.SEC_USER_AGENT || "STOCK AI contact=developer@example.com" } });
      const match = Object.values(directory).find(x => String(x.ticker).toUpperCase() === symbol);
      if (!match) return res.json({ source: "미국 증권거래위원회 SEC EDGAR", configured: true, items: [], message: "SEC 등록 기업 티커를 찾지 못했습니다." });
      const cik = String(match.cik_str).padStart(10, "0");
      const submissions = await getJson(`https://data.sec.gov/submissions/CIK${cik}.json`, { headers: { "User-Agent": process.env.SEC_USER_AGENT || "STOCK AI contact=developer@example.com" } });
      const recent = submissions.filings?.recent || {}, items = [];
      for (let i = 0; i < (recent.form || []).length; i++) {
        const date = recent.filingDate[i] || "";
        if (date.replaceAll("-", "") < since) continue;
        const accession = recent.accessionNumber[i], doc = recent.primaryDocument[i];
        if (!accession || !doc) continue;
        const accessionPath = accession.replaceAll("-", "");
        items.push({ title: `${recent.form[i]} · ${recent.primaryDocDescription[i] || "SEC 제출 문서"}`, date: date.replaceAll("-", ""), company: submissions.name,
          type: recent.form[i], url: `https://www.sec.gov/Archives/edgar/data/${Number(cik)}/${accessionPath}/${doc}`, source: "SEC EDGAR" });
        if (items.length >= 20) break;
      }
      return res.json({ source: "미국 증권거래위원회 SEC EDGAR", configured: true, items });
    }
    throw new Error("지원하지 않는 시장입니다.");
  } catch (e) { res.status(502).json({ error: e.message || "공시를 불러오지 못했습니다." }); }
});

app.post("/api/analyze-image", async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "OPENAI_API_KEY 설정이 필요합니다." });
  const { image, mimeType } = req.body || {};
  if (!image || !/^image\/(png|jpeg|webp)$/.test(mimeType || "")) return res.status(400).json({ error: "PNG, JPG, WEBP 이미지가 필요합니다." });
  try {
    const response = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "gpt-4.1-mini", input: [{ role: "user", content: [
        { type: "input_text", text: "당신은 보수적인 주식 차트 분석 보조자입니다. 이미지에 실제로 보이는 정보만 분석하세요. 단기 관점에서 추세, 지지·저항 후보, 캔들 패턴, 거래량, 이동평균선, 상승·하락 근거와 반대 시나리오를 한국어로 정리하세요. 근거 없는 확률 단정과 매매 보장은 금지하고 투자 조언이 아님을 밝혀주세요." },
        { type: "input_image", image_url: `data:${mimeType};base64,${image}` }
      ] }] }) });
    const data = await response.json(); if (!response.ok) throw new Error(data.error?.message || "AI 분석 요청 실패");
    const analysis = (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n");
    res.json({ analysis: analysis || "분석 결과를 받지 못했습니다." });
  } catch (e) { res.status(502).json({ error: e.message }); }
});
app.get("/api/health", (_req, res) => res.json({ ok: true, openaiConfigured: !!process.env.OPENAI_API_KEY, dartConfigured: !!process.env.DART_API_KEY }));
app.listen(PORT, () => console.log(`STOCK AI running: http://localhost:${PORT}`));
