const $ = id => document.getElementById(id);
let chart, candleSeries, volumeSeries, selectedFile = null, current = null;
function initChart() {
  const el = $("chart");
  chart = LightweightCharts.createChart(el, { width: el.clientWidth, height: el.clientHeight, layout: { background: { color: "#111923" }, textColor: "#8291a2", fontFamily: "DM Mono" }, grid: { vertLines: { color: "#1c2935" }, horzLines: { color: "#1c2935" } }, rightPriceScale: { borderColor: "#2b3947" }, timeScale: { borderColor: "#2b3947", timeVisible: true, secondsVisible: false }, crosshair: { mode: 1 } });
  candleSeries = chart.addCandlestickSeries({ upColor: "#36d399", downColor: "#ff687b", borderUpColor: "#36d399", borderDownColor: "#ff687b", wickUpColor: "#36d399", wickDownColor: "#ff687b" });
  volumeSeries = chart.addHistogramSeries({ priceFormat: { type: "volume" }, priceScaleId: "volume", scaleMargins: { top: .82, bottom: 0 }, color: "#426b8d" });
  new ResizeObserver(() => chart.applyOptions({ width: el.clientWidth, height: el.clientHeight })).observe(el);
}
function ema(a, p) { const k = 2 / (p + 1), out = []; a.forEach((v, i) => out.push(i ? v * k + out[i - 1] * (1 - k) : v)); return out; }
function rsi(a, p = 14) { if (a.length <= p) return null; let g = 0, l = 0; for (let i = 1; i <= p; i++) { const d = a[i] - a[i - 1]; if (d > 0) g += d; else l -= d; } let ag = g / p, al = l / p; for (let i = p + 1; i < a.length; i++) { const d = a[i] - a[i - 1]; ag = (ag * (p - 1) + Math.max(d, 0)) / p; al = (al * (p - 1) + Math.max(-d, 0)) / p; } return al === 0 ? 100 : 100 - 100 / (1 + ag / al); }
function analyze(cs) {
  const c = cs.map(x => x.close), v = cs.map(x => x.volume), e20 = ema(c, 20), e50 = ema(c, 50), e12 = ema(c, 12), e26 = ema(c, 26), m = e12.map((x, i) => x - e26[i]), sig = ema(m, 9), rv = rsi(c);
  let bull = 0, bear = 0;
  if (e20.at(-1) > e50.at(-1)) bull += 25; else bear += 25;
  if (c.at(-1) > e20.at(-1)) bull += 15; else bear += 15;
  if (m.at(-1) > sig.at(-1)) bull += 25; else bear += 25;
  if (rv !== null) { if (rv >= 50 && rv < 70) bull += 20; else if (rv < 50 && rv > 30) bear += 20; else if (rv >= 70) bear += 10; else bull += 10; }
  const recent = v.slice(-5).reduce((a, b) => a + b, 0) / Math.min(5, v.length), older = v.slice(-20, -5), prior = older.length ? older.reduce((a, b) => a + b, 0) / older.length : recent;
  if (recent > prior) { if (c.at(-1) > c.at(-2)) bull += 15; else bear += 15; }
  const total = bull + bear || 1, score = Math.round(bull / total * 100);
  $("score").textContent = score; $("bullScore").textContent = `${Math.round(bull / total * 100)}%`; $("bearScore").textContent = `${Math.round(bear / total * 100)}%`;
  $("bullBar").style.width = `${bull / total * 100}%`; $("bearBar").style.width = `${bear / total * 100}%`;
  $("scoreRing").style.background = `conic-gradient(${score >= 55 ? "#36d399" : "#ff687b"} ${score * 3.6}deg,#243340 0deg)`;
  $("signalTag").textContent = score >= 65 ? "상승 신호 우세" : score <= 35 ? "하락 신호 우세" : "혼조 / 중립";
  $("signalTag").style.color = score >= 65 ? "#36d399" : score <= 35 ? "#ff687b" : "#d5b76b";
  $("rsi").textContent = rv === null ? "—" : rv.toFixed(1); $("rsiState").textContent = rv === null ? "데이터 부족" : rv >= 70 ? "과매수" : rv <= 30 ? "과매도" : "중립";
  $("macd").textContent = m.at(-1) > sig.at(-1) ? "상승 교차" : "하락 교차"; $("macdState").textContent = `MACD ${((m.at(-1) - sig.at(-1))).toPrecision(3)}`;
  $("ema").textContent = e20.at(-1) > e50.at(-1) ? "정배열" : "역배열"; $("emaState").textContent = `EMA20 ${e20.at(-1) > e50.at(-1) ? "위" : "아래"} EMA50`;
  $("volumeState").textContent = recent > prior ? "증가" : "감소"; $("volumeDetail").textContent = "최근 5개 / 이전 평균";
}
function fmt(n, currency) { return currency === "KRW" ? "₩" + Number(n).toLocaleString("ko-KR", { maximumFractionDigits: 0 }) : "$" + Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 }); }
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
async function loadMarket() {
  const market = $("market").value, board = $("board").value, symbol = $("symbol").value.trim().toUpperCase();
  $("connection").textContent = "데이터 요청 중"; $("loadBtn").disabled = true;
  try {
    const r = await fetch(`/api/market?market=${market}&board=${board}&symbol=${encodeURIComponent(symbol)}`), d = await r.json(); if (!r.ok) throw Error(d.error);
    current = d; $("stockName").innerHTML = `${esc(d.name)} <em>${esc(d.ticker)}</em>`; $("price").textContent = fmt(d.price, d.currency);
    $("change").textContent = `${d.change24 >= 0 ? "+" : ""}${d.change24.toFixed(2)}%`; $("change").style.color = d.change24 >= 0 ? "#36d399" : "#ff687b";
    $("highLow").textContent = `${fmt(d.high24, d.currency)} / ${fmt(d.low24, d.currency)}`; $("marketLabel").textContent = market === "kr" ? (board === "kospi" ? "코스피" : "코스닥") : "미국 주식";
    $("lowValue").textContent = fmt(d.low24, d.currency); $("highValue").textContent = fmt(d.high24, d.currency); $("volume24").textContent = Number(d.volume24).toLocaleString("ko-KR");
    const pct = (d.price - d.low24) / (d.high24 - d.low24 || 1) * 100; $("rangeMarker").style.left = `${Math.max(0, Math.min(100, pct))}%`;
    candleSeries.setData(d.candles); volumeSeries.setData(d.candles.map(x => ({ time: x.time, value: x.volume, color: x.close >= x.open ? "#287d6b88" : "#a94d5d88" }))); chart.timeScale().fitContent(); analyze(d.candles);
    $("updated").textContent = new Date().toLocaleTimeString("ko-KR"); $("connection").textContent = "데이터 수신 완료";
    loadFilings();
  } catch (e) { $("connection").textContent = "연결 오류"; $("price").textContent = "데이터 오류"; $("signalTag").textContent = "조회 실패"; $("filingList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
  finally { $("loadBtn").disabled = false; }
}
async function loadFilings() {
  if (!current) return;
  const market = $("market").value, symbol = $("symbol").value.trim().toUpperCase();
  $("filingList").innerHTML = '<div class="empty">공식 공시를 확인하고 있습니다…</div>';
  try {
    const r = await fetch(`/api/filings?market=${market}&symbol=${encodeURIComponent(symbol)}`), data = await r.json(); if (!r.ok) throw Error(data.error);
    $("filingSource").textContent = data.source || "공식 공시";
    if (!data.items?.length) { $("filingList").innerHTML = `<div class="empty">${esc(data.message || "최근 120일 내 조회된 공시가 없습니다.")}</div>`; return; }
    $("filingList").innerHTML = data.items.map(item => `<a class="filing-item" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer"><span class="filing-date">${item.date.slice(0,4)}.${item.date.slice(4,6)}.${item.date.slice(6,8)}</span><span class="filing-content"><b>${esc(item.title)}</b><small>${esc(item.company)} · ${esc(item.type)} · ${esc(item.source)}</small></span><span class="filing-arrow">↗</span></a>`).join("");
  } catch (e) { $("filingSource").textContent = "공식 출처 연결 필요"; $("filingList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function syncMarket() { const kr = $("market").value === "kr"; $("boardWrap").style.display = kr ? "block" : "none"; $("symbol").value = kr ? "005930" : "AAPL"; }
$("market").addEventListener("change", () => { syncMarket(); loadMarket(); }); $("loadBtn").addEventListener("click", loadMarket); $("refreshBtn").addEventListener("click", loadMarket); $("filingBtn").addEventListener("click", loadFilings);
$("symbol").addEventListener("keydown", e => { if (e.key === "Enter") loadMarket(); });
$("imageInput").addEventListener("change", e => { selectedFile = e.target.files[0]; if (!selectedFile) return; if (selectedFile.size > 10 * 1024 * 1024) { alert("10MB 이하 이미지를 선택하세요."); selectedFile = null; return; } $("fileName").textContent = selectedFile.name; $("analyzeBtn").disabled = false; $("imageResult").classList.add("hidden"); });
$("dropzone").addEventListener("dragover", e => e.preventDefault()); $("dropzone").addEventListener("drop", e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f && f.type.startsWith("image/")) { $("imageInput").files = e.dataTransfer.files; $("imageInput").dispatchEvent(new Event("change")); } });
$("analyzeBtn").addEventListener("click", () => { if (!selectedFile) return; $("analyzeBtn").disabled = true; $("analyzeBtn").textContent = "AI가 차트를 분석하고 있습니다…"; const reader = new FileReader(); reader.onload = async () => { try { const [head, b64] = reader.result.split(","), mime = head.match(/:(.*?);/)[1], r = await fetch("/api/analyze-image", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ image: b64, mimeType: mime }) }), d = await r.json(); if (!r.ok) throw Error(d.error); $("imageResult").textContent = d.analysis; $("imageResult").classList.remove("hidden"); } catch (e) { $("imageResult").textContent = e.message; $("imageResult").classList.remove("hidden"); } finally { $("analyzeBtn").disabled = false; $("analyzeBtn").innerHTML = '이미지 AI 분석하기 <span>→</span>'; } }; reader.readAsDataURL(selectedFile); });
initChart(); syncMarket(); loadMarket(); setInterval(loadMarket, 60000);
fetch("/api/health").then(r => r.json()).then(s => { if (!s.dartConfigured) { $("filingSource").textContent = "국내 공시는 DART API 키 필요"; if ($("market").value === "kr") $("filingList").innerHTML = '<div class="empty">.env 파일에 DART_API_KEY를 설정하면 국내 공시를 볼 수 있습니다.</div>'; } if (!s.openaiConfigured) $("fileName").textContent = "이미지 AI 분석은 OpenAI API 키 설정 후 사용 가능"; }).catch(() => {});
