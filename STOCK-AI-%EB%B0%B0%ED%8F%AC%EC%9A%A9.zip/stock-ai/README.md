# STOCK AI — 국내 + 미국 단기 주식 분석

깔끔한 다크 금융 터미널 형태의 Node.js 웹 대시보드입니다. 코스피·코스닥 6자리 종목코드와 미국 티커를 조회할 수 있습니다.

## 실행
1. Node.js 18 이상 설치
2. 프로젝트 폴더에서 `npm install`
3. `.env.example`을 복사해 `.env`로 이름 변경
4. 필요한 API 키 설정
5. `npm start`
6. 브라우저에서 `http://localhost:3000`

## 주요 기능
- 국내/미국 주식 가격 및 최근 5일 5분봉 차트
- 60초 자동 갱신
- RSI(14), EMA(20/50), MACD(12/26/9), 거래량 비교 기반 단기 참고 신호
- 차트 이미지 업로드 AI 분석 (OpenAI API 키 필요)
- X/소셜 게시글 분석 기능은 제거
- 국내 기업 공시: 금융감독원 OpenDART 원문 연결 (DART API 키 필요)
- 미국 기업 제출자료: SEC EDGAR 공식 제출자료 원문 연결 (API 키 불필요, User-Agent 연락처 설정 권장)

## API 키 설정
`.env` 예시:
```env
PORT=3000
OPENAI_API_KEY=your_openai_api_key
DART_API_KEY=your_opendart_key
SEC_USER_AGENT=STOCK AI contact=your-real-email@example.com
```

- OpenDART 키: https://opendart.fss.or.kr/ 에서 발급
- 미국 SEC EDGAR API는 SEC 공식 공개 API이며 API 키 없이 제출 내역을 조회할 수 있습니다. SEC의 공정 접근 정책에 따라 식별 가능한 User-Agent와 실제 연락처를 설정하세요.
- 이미지 분석 기능은 OpenAI API 사용량에 따라 비용이 발생할 수 있습니다.

## 데이터 출처 및 제한
- 주가 차트는 Yahoo Finance의 비공식 공개 차트 엔드포인트를 사용합니다. 거래소 공식 실시간 시세가 아니며 지연·제한이 있을 수 있습니다.
- 국내 공시는 금융감독원 OpenDART, 미국 공시는 SEC EDGAR에서 직접 조회합니다. 공시 원문을 확인할 수 있도록 출처 링크를 제공합니다.
- 국내 공시를 처음 조회할 때 DART 기업 코드 파일을 내려받아 메모리에 캐시합니다.
- 공시가 없다고 해당 기업에 뉴스나 위험 요인이 없다는 의미는 아닙니다.

## 분석 점수 유의사항
상승/하락 점수는 표시된 기술 지표를 단순 규칙으로 합산한 참고용 값이며, 통계적으로 검증된 예측 확률이 아닙니다. 매수·매도 권유나 수익 보장이 아닙니다. 실제 전략으로 사용하려면 백테스트, 수수료·슬리피지, 리스크 관리 검증이 필요합니다.

## 배포 전 확인
실제 서비스 공개 전에는 정식 시세 데이터 라이선스, 인증, 요청 제한, 캐시, 로그, HTTPS, 업로드 보안 등을 추가하세요. SEC_USER_AGENT에는 실제 연락 가능한 이메일을 넣으세요.


## Render 배포 설정
이 프로젝트에는 `render.yaml` Blueprint 설정이 포함되어 있습니다. GitHub 저장소에 업로드한 뒤 Render에서 Blueprint로 연결하면 Node 웹 서비스로 배포할 수 있습니다. 서비스는 `PORT` 환경변수를 자동으로 사용하며 `/api/health` 상태 확인 경로를 제공합니다.

배포 후 국내 DART 공시와 이미지 AI 분석을 쓰려면 Render 서비스 환경변수에 각각 `DART_API_KEY`, `OPENAI_API_KEY`를 등록해야 합니다. 미국 SEC 공시는 `SEC_USER_AGENT`에 실제 연락 가능한 이메일을 포함해 설정하는 것을 권장합니다. 키를 설정하지 않아도 주가 차트와 SEC 자료 기능은 일부 이용할 수 있습니다.
